/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 *   SPDX-License-Identifier: Apache-2.0
 */

package arq.cmdline;


import org.apache.jena.cmd.ArgDecl;
import org.apache.jena.cmd.CmdArgModule;
import org.apache.jena.cmd.CmdGeneral;
import org.apache.jena.cmd.ModBase;
import org.apache.jena.query.ResultSet;
import org.apache.jena.sparql.core.Prologue;
import org.apache.jena.sparql.resultset.ResultsFormat;
import org.apache.jena.sparql.util.QueryExecUtils;

public class ModResultsOut extends ModBase {
    protected final ArgDecl resultsFmtDecl = new ArgDecl(ArgDecl.HasValue, "results", "out", "rfmt");

    private ResultsFormat resultsFormat  = ResultsFormat.TEXT;

    @Override
    public void processArgs(CmdArgModule cmdline) throws IllegalArgumentException {
        if ( cmdline.contains(resultsFmtDecl) ) {
            String rFmt = cmdline.getValue(resultsFmtDecl);
            resultsFormat = ResultsFormat.lookup(rFmt);
            if ( resultsFormat == null )
                cmdline.cmdError("Unrecognized output format: " + rFmt);
        }
    }

    @Override
    public void registerWith(CmdGeneral cmdLine) {
        cmdLine.getUsage().startCategory("Results");
        cmdLine.add(resultsFmtDecl,
                    "--results=",
                    "Results format (Result set: text, XML, JSON, CSV, TSV; Graph: RDF serialization)");
    }

    public void checkCommandLine(CmdArgModule cmdLine) {}

    public void printResultSet(ResultSet resultSet, Prologue prologue) {
        QueryExecUtils.outputResultSet(resultSet, prologue, resultsFormat, System.out);
    }

    public ResultsFormat getResultsFormat() {
        return resultsFormat;
    }
}
